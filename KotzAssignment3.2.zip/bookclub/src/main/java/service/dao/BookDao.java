package service.dao;

import model.Book;
import service.GenericDao;

public interface BookDao extends GenericDao<Book, String> {

}
